void BubbleSort(int len, int*arr);

void ShellSort(int len, int*arr);

void InsertionSort(int len, int*arr);

void SelectionSort(int len, int* arr);

void HeapSort(int len, int* arr);

void QuickSort(int len, int*arr);

void MergeSort(int len, int*arr);

void CountingSort(int len, int*arr);
//  Quick sort  QS
//  Merge sort MS
//  Counting sort  CS