from math import log, log2
import matplotlib.pyplot as plt
import os

directory = 'output'
sorts = {}
# iterate over files in
# that directory
for dirname in os.listdir(directory):

    for filename in os.listdir(os.path.join(directory,dirname)):
        # if filename == "BUBBLE SORT":
        #     continue
        # if filename == "SELECTION SORT":
        #     continue
        # if filename == "INSERTION SORT":
        #     continue
        f = os.path.join(directory,dirname, filename)
        # checking if it is a file
        if os.path.isfile(f):
            sorts[filename] = {}
            with open(f) as file:
                for line in file:
                    n,time = [int(k) for k in line.split()]
                    if n not in sorts[filename]:
                        sorts[filename][n] = []
                    sorts[filename][n].append(time)
    fig = plt.figure()
    ax = plt.subplot(111)
    for algorithm in sorts:
        for n in sorts[algorithm]:
            sorts[algorithm][n] = sum(sorts[algorithm][n])/len(sorts[algorithm][n])
        times = []
        elements = []
        for i in sorted(sorts[algorithm]):
            elements.append(i)
            times.append(sorts[algorithm][i])
        ax.plot(elements,times, label=algorithm)
        
    ax.plot(elements,elements,label='linear')
    ax.plot(time,time,label='linear2')
    squared = []
    nlogn = []
    for i in elements:
        # squared.append(i*i)
        nlogn.append(i * log2(i))
    # ax.plot(elements,squared,label='sqared/4')
    ax.plot(elements,nlogn,label='nlogn')
    ax.legend()
    plt.title("Sorting algorithms complexity, distribution: "+dirname)
    plt.ylabel("Time")
    plt.xlabel("Elements")

    plt.show()
