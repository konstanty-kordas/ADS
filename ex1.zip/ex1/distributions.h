#include <stdlib.h>

void uniform(int len,int*arr);

void constant(int len, int*arr);

void ascending(int len, int*arr);

void descending(int len, int*arr);

void AShape(int len, int*arr);

void VShape(int len, int*arr);