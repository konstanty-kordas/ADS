void BubbleSort(int len, int*arr){
    int x;
    bool flag = false;
    for (int i=0;i<len;i++){
        for (int j=i+1;j<len;j++){
            if (arr[i]>arr[j]){
                x = arr[j];
                arr[j] = arr[i];
                arr[i] = x;
                flag=false;
            }
        }
        if (flag){
            break;
        }
    }
}

void ShellSort(int len, int*arr){

    int j,temp;
    for (int gap = len/2; gap > 0; gap /= 2)
    {
        for (int i = gap; i < len; i += 1)
        {
            temp = arr[i];
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                arr[j] = arr[j - gap];
            }
            arr[j] = temp;
        }
    }
}

void InsertionSort(int len, int*arr){
    int x,j;
    for (int i = 1; i < len; i++){
        x = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > x)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = x;
    }
}

void SelectionSort(int len, int* arr){
    int k, x;
    for (int i=0;i<len;i++){
        x = arr[i];
        k = i;
        for (int j=i+1;j<len;j++){
            if (arr[j]<x){
                k=j;
                x = arr[k];
            }
        }
        arr[k] = arr[i];
        arr[i] = x;
    }
}

void heapify(int arr[], int n, int i)
{
    int x;
    int largest = i; 
    int l = 2 * i + 1; 
    int r = 2 * i + 2; 
    if (l < n && arr[l] > arr[largest])
        largest = l;
    if (r < n && arr[r] > arr[largest])
        largest = r;
    if (largest != i) {
        x = arr[largest];
        arr[i] = arr[largest];
        arr[largest] = x;
        heapify(arr, n, largest);
    }
}


void HeapSort(int len, int* arr){
    int x;
    for (int i = len / 2 - 1; i >= 0; i--)
        heapify(arr, len, i);
    for (int i = len - 1; i >= 0; i--) {
        // Move current root to end
        x = arr[0];
        arr[0] = arr[i];
        arr[i] = x;
        heapify(arr, i, 0);
    }
}
