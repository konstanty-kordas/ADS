#include <iostream>
#include <chrono>
#include <functional>
#include <string>
#include <fstream>

#include "sorts.h"
#include "distributions.h"



void timeSort(int len, 
                    std::function<void(int, int*)> distribution,
                    std::string distributionName,
                    std::function<void(int, int*)> algorithm,
                    std::string algorithmName,
                    bool print=false){
    int *arr = (int*)malloc(sizeof(int) * len);
    distribution(len,arr);
    auto start = std::chrono::high_resolution_clock::now();
    algorithm(len,arr);
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
    if (print){
        std::cout <<"Algorithm: "<< algorithmName << "\nDistribution: "<< distributionName <<"\nTakes: ";
        std::cout << duration.count() << " microseconds" << std::endl;
        for (int i=0;i<len;i++){
            std::cout<<arr[i]<<"\t";
        }
    }
    std::ofstream file;
    file.open("./output/"+distributionName+'/'+algorithmName,std::ios::app);
    file<<len<<'\t'<<duration.count()<<std::endl;
    file.close();
}
int main(){     
    std::function<void (int, int *)>* distributions = 
                                    (std::function<void (int, int *)>*) 
                                    malloc(sizeof(std::function<void (int, int *)>) * 6);
    distributions[0] = uniform;
    distributions[1] = constant;
    distributions[2] = ascending;
    distributions[3] = descending;
    distributions[4] = AShape;
    distributions[5] = VShape;
    std::string* distributionNames =(std::string *)malloc(sizeof(std::string) * 6);
    distributionNames[0] = "UNIFORM";
    distributionNames[1] = "CONSTANT";
    distributionNames[2] = "ASCENDING";
    distributionNames[3] = "DESCENDING";
    distributionNames[4] = "ASHAPE";
    distributionNames[5] = "VSHAPE";
    for (int k=0;k<15;k++){
        for (int j=0;j<6;j++){
            for (int i=100;i<10000;i+=100){
                timeSort(i, distributions[j], distributionNames[j], ShellSort, "SHELL SORT",false);
                timeSort(i, distributions[j], distributionNames[j],BubbleSort,"BUBBLE SORT", false);
                timeSort(i, distributions[j], distributionNames[j],SelectionSort, "SELECTION SORT",false);
                timeSort(i, distributions[j], distributionNames[j],InsertionSort, "INSERTION SORT",false);
                timeSort(i, distributions[j], distributionNames[j],HeapSort, "HEAP SORT",false);
            }
        }
    }
    return 0;
}
